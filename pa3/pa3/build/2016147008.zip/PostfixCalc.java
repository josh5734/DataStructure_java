/*
* Name: jo sung hyeon
* Student ID #: 2016147008
*/

/*
* Do NOT import any additional packages/classes.
* If you (un)intentionally use some additional packages/classes we did not
* provide, you may receive a 0 for the homework.
*/

public class PostfixCalc implements ICalc {
    public IStack<Integer> stack;
    /* Use some variables for your implementation. */
    
    int first_operand;
    int second_operand;
    int answer;
    public PostfixCalc() {
        this.stack = new Stack<>();
        /*
        * Constructor
        */
        
    }

    @Override
    public int evaluate(String expression) {
        /*
        * Function input:
        *  + expression: A postfix expression.
        *
        * Job:
        *  Return the value of the given expression.
        *
        * The postfix expression is a valid expression with
        * length of at least 1.
        * There are +(addition), -(subtraction) and *(multiplication)
        * operators and only non-negative integers, seperated with
        * a single space symbol.
        */
    	String[] array = expression.split(" ");
    	for(String x : array) {
    		if(x.equals("+") || x.equals("-") || x.equals("*")) {
    			first_operand = stack.pop();
    			second_operand = stack.pop();
    			
    			switch (x) {
	    			case "+":
	    				answer = second_operand + first_operand;
	    				break;
	    			case "-":
	    				answer = second_operand - first_operand;
	    				break;
	    			case "*":
	    				answer = second_operand * first_operand;
	    				break;
    			}
    			stack.push(answer);
    			
    			
    		}
    		else {
    			answer = Integer.parseInt(x);
    			stack.push(answer);
    		}	
    	}
        return answer;
    }
}
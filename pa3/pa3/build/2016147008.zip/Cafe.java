/*
 * Name: jo sung hyeon
 * Student ID #: 2016147008
 */

/* 
 * Do NOT import any additional packages/classes.
 * If you (un)intentionally use some additional packages/classes we did not
 * provide, you may receive a 0 for the homework.
 */

public final class Cafe implements ICafe {
    /*
    * Use some variables for your implementation.
    */
	public Queue<String> waitLine = new Queue<String>();
	public Queue<String> server1 = new Queue<String>();
	public Queue<String> server2 = new Queue<String>();
	
	int statTime;
	int time1;
	int time2;

	public Cafe() {
        /*
        * Constructor
        * This function is an initializer for this class.
        */
		statTime = 0;
		time1 = 0;
		time2 = 0;
		
	}
	
    
    @Override
    public void arrive(int Id, int arrivaltime, int coffee) {
        /*
        * Function input:
        *  + Id: Students Id
        *  + arrivaltime: Students arrival time
        *  + coffee: Time needed to prepare the coffee
        *
        * Job:
        *  Save the information to use later.
        */
    	waitLine.add(Integer.toString(Id) + " " + Integer.toString(arrivaltime) + " " + Integer.toString(coffee));	
    }


    @Override
    public int serve() {
        /**
         * Function input: Nothing
         * 
         * Job:
         *  Serve the coffee to a strudent when ready. Return the student's Id.
         */
    	int answer = 0;

    	
    	if(server1.isEmpty() && !waitLine.isEmpty() && time1 <= time2) {
    		server1.add(waitLine.remove());
    		if(time1 <= Integer.parseInt(server1.peek().split(" ")[1])) {
    			time1 = Integer.parseInt(server1.peek().split(" ")[1]) + Integer.parseInt(server1.peek().split(" ")[2]);
    		}
    		else {
    			time1 +=   Integer.parseInt(server1.peek().split(" ")[2]);
    		}
    		
    	}
    	if(server1.isEmpty() && !waitLine.isEmpty() && time1 >= time2) {
   
    		server2.add(waitLine.remove());
    		if(time2 <= Integer.parseInt(server2.peek().split(" ")[1])) {
    			time2 = Integer.parseInt(server2.peek().split(" ")[1]) + Integer.parseInt(server2.peek().split(" ")[2]);
    		}
    		else {
    			time2 +=   Integer.parseInt(server2.peek().split(" ")[2]);
    		}
    	
    	}
    	
    	
    	
    	
    	if(!server1.isEmpty() && !waitLine.isEmpty()) {
    	
    		server2.add(waitLine.remove());
    		if(time2 <= Integer.parseInt(server2.peek().split(" ")[1])) {
    			time2 = Integer.parseInt(server2.peek().split(" ")[1]) + Integer.parseInt(server2.peek().split(" ")[2]);
    		}
    		else {
    			time2 +=   Integer.parseInt(server2.peek().split(" ")[2]);
    		}
    	
    	}
    	if(server1.isEmpty() && server2.isEmpty() && !waitLine.isEmpty()) {
  
    		server1.add(waitLine.remove());
    		if(time1 <= Integer.parseInt(server1.peek().split(" ")[1])) {
    			time1 = Integer.parseInt(server1.peek().split(" ")[1]) + Integer.parseInt(server1.peek().split(" ")[2]);
    		}
    		else {
    			time1 +=   Integer.parseInt(server1.peek().split(" ")[2]);
    		}
    		
    	}
        	
    	
    	//server1 serve
    	if(server2.isEmpty() ||  ((time1 <= time2) && !server1.isEmpty()) ) {
    		if(time1 == Integer.parseInt(server1.peek().split(" ")[1]) + Integer.parseInt(server1.peek().split(" ")[2])){
    			statTime += Integer.parseInt(server1.peek().split(" ")[2]);
        		answer = Integer.parseInt(server1.remove().split(" ")[0]);
    		}else {
    			statTime += time1 - Integer.parseInt(server1.peek().split(" ")[1]);
        		answer = Integer.parseInt(server1.remove().split(" ")[0]);
    		}
    	
    	
    		

    	//server2 serve	
    	}else{
    		if(time2 == Integer.parseInt(server2.peek().split(" ")[1]) + Integer.parseInt(server2.peek().split(" ")[2])){
    			statTime += Integer.parseInt(server2.peek().split(" ")[2]);
        		answer = Integer.parseInt(server2.remove().split(" ")[0]);
    		}else {
    			statTime += time2 - Integer.parseInt(server2.peek().split(" ")[1]);
        		answer = Integer.parseInt(server2.remove().split(" ")[0]);
    		}
    
    
    	}

		return answer;
    }

    	
 
    @Override
    public int stat() {
        /**
         * Function input: Nothing
         * 
         * Job:
         *  Calculate the sum of the waiting time of the served students.
         */
    
        return statTime;
    }

}

// Queue class
class Queue<E> {

	private Node<E> first;
	private Node<E> last;
	
    
    public void add(E item) {
    	Node<E> t = new Node<E>(item);
    	
    	if(last != null) {
    		last.setNext(t);
    	}
    	last = t;
    	if(first == null) {
    		first = last;
    		
    	}
    }
    public E remove() {
    	E data = first.getValue();
    	first = first.getNext();
    	
    	if(first == null) {
    		last = null;
    	}
    	return data;
    }
    
    public E peek() {
    	return first.getValue();
    }
    
    public boolean isEmpty() {
    	return first == null;
    	
    }
}

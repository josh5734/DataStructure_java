/*
* Name: jo sung hyeon
* Student ID#: 2016147008
*/

/*
* Do NOT use any external packages/classes.
* If you (un)intentionally use them we did not provide,
* you will get 0.
* Also do NOT use auto-import function on IDEs.
* If the import statements change, you will also get 0.
*/

import java.util.List;
import java.util.ArrayList;

public final class Tree<E> implements ITree<E> {
	
    private TreeNode<E> root = null;
    private int arity=0;
	private int size = 0;
    public ArrayList<TreeNode<E>> parent;
    public ArrayList<TreeNode<E>> child;

    
    public Tree(int arity) {
        /*
        * Input:
        *  + arity: max number of node's children. always positive.
        */
    	this.parent = new ArrayList<>();

    	this.child = new ArrayList<>();
    	this.arity = arity;
    	
    }

    @Override
    public TreeNode<E> root() throws IllegalStateException {
        /*
        * Return the root node.
        * If there is no root, raise an IllegalStateException.
        */
    	if(size == 0) {
    		throw new IllegalStateException();
    	}else {
    		return root;
    	}
    }

    @Override
    public int arity() {
        /*
        * Return the max number of children its node can have
        */
        return arity;
    }

    @Override
    public int size() {
        /*
        * Return the number of nodes in this tree.
        */
        return size;
    }

    @Override
    public boolean isEmpty() {
        /*
        * Return true if this tree is empty.
        */
        return (size ==0);
    }

    @Override
    public int height() throws IllegalStateException {
        /*
        * Return height of this tree.
        * If there are no nodes in this tree,
        * raise an IllegalStateException.
        */
    	int height = 0;
    	if(size == 0) {
    		throw new IllegalStateException();
    	}else {
    		TreeNode<E> node = root;
    		while(node.numChildren() != 0) {
    			height++;
    			node = node.getChild(0);
    		}	
    	}
        return height;
    }

    @Override
    public TreeNode<E> add(E item) {
        /*
        * Insert the given node at the *end* of this tree and
        * return THE inserted NODE.
        * *End* means that the leftmost possible slot of
        * smallest depth of this tree.
        */
    	
    	TreeNode<E> newNode = new TreeNode<E>(arity, item);
    	if(size == 0) 
    	{
    		root = newNode;	
    		parent.add(root);
    		size++;
    		return root;
    	}
    	else 
    	{
    		TreeNode<E> parentNode = parent.get(parent.size()-1);

			if(parentNode.numChildren() == parentNode.maxChildren()) {
    			parent.remove(parent.size()-1);
    			if(parent.size() == 0) {
    				while(child.size() != 0) {
    					parent.add(child.remove(child.size()-1));
    				}
    			}
    			parentNode = parent.get(parent.size()-1);
				parentNode.insertChild(parentNode.numChildren(), newNode);
    			newNode.setParent(parentNode);
    			child.add(newNode);
    	
    		}
    		else {
    				parentNode.insertChild(parentNode.numChildren(), newNode);
        			newNode.setParent(parentNode);
        			child.add(newNode);
        	
    		}
		}
    	
    	size++;
        return newNode;
    }

    @Override
    public void detach(TreeNode<E> node) throws IllegalArgumentException {
        /*
        * Detach the given node (and its descendants) from this tree.
        * if the node is not in this tree,
        * raise an IllegalArgumentException.
        */
    	boolean flag = false;
    	List<TreeNode<E>> items = finder();
    	for(TreeNode<E> item : items) {
    		if(node.equals(item)) flag = true;
    	}
    	if(!flag) throw new IllegalArgumentException();
    	
    	if(node.equals(root)) {
    		for(int i = 0; i < root.numChildren(); i++) {
    			root.removeChild(i);
    		}
    		root = null;
    		size = 0;
    	}
    	else {
    		TreeNode<E> subParent = node.getParent();
        	int cursor = 0;
        	for(int i = 0 ; i < subParent.numChildren(); i++) {
        		if(subParent.getChild(i).equals(node)) {
        			cursor = i;
        			break;
        		}
        	}
        	subParent.removeChild(cursor);
        	List<E> toFindSize = depthOrder();
        	size = toFindSize.size();
    	}
    	
    	
    }

    @Override
    public List<E> preOrder() {
        /*
        * Return the sequence of items visited by preorder traversal.
        * If there are no nodes, return an empty list, NOT NULL.
        */
        List<E> preOrder_list = new ArrayList<>();
        preOrder_trav(root, preOrder_list);
        return preOrder_list;
    }

    @Override
    public List<E> postOrder() {
        /*
        * Return the sequence of items visited by postorder traversal.
        * If there are no nodes, return an empty list, NOT NULL.
        */
    	List<TreeNode<E>> stack = new ArrayList<>();
    	List<E> postOrder_list = new ArrayList<>();
    	
    	if(root == null) {
    		return postOrder_list;
    		
    	}
    	
    	stack.add(root);
    	while(!stack.isEmpty()) {
    		TreeNode<E> node = stack.remove(stack.size()-1);
    		postOrder_list.add(0, node.getValue());
    		for(int i = 0; i < node.numChildren(); i++) {
    			stack.add(node.getChild(i));
    		}
    	}
        return postOrder_list;
    }

    @Override
    public List<E> depthOrder() {
        /*
        * Return the sequence of items visited by depthorder traversal.
        * If there are no nodes, return an empty list, NOT NULL.
        */
    	List<TreeNode<E>> stack = new ArrayList<>();
    	List<E> depthOrder_list = new ArrayList<>();
    	
    	if(root == null) {
    		return depthOrder_list;
    	}
    	
    	stack.add(root);
    	while(!stack.isEmpty()) {
    		TreeNode<E> node = stack.remove(0);
    		depthOrder_list.add(node.getValue());
    		for(int i = 0; i < node.numChildren(); i++) {
    			stack.add(node.getChild(i));
    		}
    	}
        return depthOrder_list;
    }
    

    
    private void preOrder_trav(TreeNode<E> node, List<E> list) {
    	if(node == null) return;
    	list.add(node.getValue());
    	for(int i = 0; i < node.numChildren(); i++) {
    		preOrder_trav(node.getChild(i), list);
    	}
    	
    }
    
    private List<TreeNode<E>> finder(){
    	
	List<TreeNode<E>> stack = new ArrayList<>();
	List<TreeNode<E>> depthOrder_list = new ArrayList<>();
	
	if(root == null) {
		return depthOrder_list;
	}
	
	stack.add(root);
	while(!stack.isEmpty()) {
		TreeNode<E> node = stack.remove(0);
		depthOrder_list.add(node);
		for(int i = 0; i < node.numChildren(); i++) {
			stack.add(node.getChild(i));
		}
	}
    return depthOrder_list;
}
}
/*
 * Name: jo sung hyeon
 * Student ID #: 2016147008
 */

/* 
 * Do NOT import any additional packages/classes.
 * If you (un)intentionally use some additional packages/classes we did not
 * provide, you may receive a 0 for the homework.
 */

public final class Stack<E> implements IStack<E> {
    public Node<E> top;
    /*
    * Use some variables for your implementation.
    */
    public int size;
    public int index;
    
    public Stack() {
        /*
        * Constructor
        * This function is an initializer for this class.
        */
    	top = null;
    	size = 0;
    	index = -1;
    	
    }
    

    @Override
    public void push(E item) {
        /*
        * Function input:
        *  item: an item to be inserted.
        *
        * Job:
        *  Insert the item at the top of the stack.
        */
    	Node<E> newNode = new Node(item);
    	newNode.setNext(top);
    	top = newNode;
    	size++;
    }

    @Override
    public E pop() throws IllegalStateException {
        /*
        * Function input:
        *  item: an item to be inserted.
        *
        * Job:
        *  Remove an item from the top of the stack and return that item.
        */
    	if(isEmpty()) {
    		throw new IllegalStateException();
    	}
    	Node<E> temp = top;
    	top = top.getNext();
    	size--;
        return temp.getValue();
    }

    @Override
    public int size() {
        /*
        * Function input: Nothing
        *
        * Job:
        *  Return the number of items in the stack.
        */
        return size;
    }

    @Override
    public boolean isEmpty() {
        /* You must not edit this function. */
        return size == 0;
    }
    
}
